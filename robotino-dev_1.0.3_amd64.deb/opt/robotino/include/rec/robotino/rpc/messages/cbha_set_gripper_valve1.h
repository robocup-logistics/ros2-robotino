#ifndef _REC_ROBOTINO_RPC_CBHA_SET_GRIPPER_VALVE1_H_
#define _REC_ROBOTINO_RPC_CBHA_SET_GRIPPER_VALVE1_H_

#include "rec/rpc/serialization/Primitive.h"

DEFINE_PRIMITIVE_TOPICDATA( rec_robotino_rpc_cbha_set_gripper_valve1, bool )

#endif //_REC_ROBOTINO_RPC_CBHA_SET_GRIPPER_VALVE1_H_
