#ifndef _REC_ROBOTINO_RPC_START_HOTSWAP_H_
#define _REC_ROBOTINO_RPC_START_HOTSWAP_H_

#include "rec/rpc/serialization/Primitive.h"

DEFINE_EMPTY_TOPICDATA( rec_robotino_rpc_start_hotswap )


#endif //_REC_ROBOTINO_RPC_START_HOTSWAP_H_
