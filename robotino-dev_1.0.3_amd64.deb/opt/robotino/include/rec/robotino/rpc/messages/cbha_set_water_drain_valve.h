#ifndef _REC_ROBOTINO_RPC_CBHA_SET_WATER_DRAIN_VALVE_H_
#define _REC_ROBOTINO_RPC_CBHA_SET_WATER_DRAIN_VALVE_H_

#include "rec/rpc/serialization/Primitive.h"

DEFINE_PRIMITIVE_TOPICDATA( rec_robotino_rpc_cbha_set_water_drain_valve, bool )

#endif //_REC_ROBOTINO_RPC_CBHA_SET_WATER_DRAIN_VALVE_H_
