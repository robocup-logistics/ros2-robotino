#ifndef _REC_ROBOTINO_RPC_COMMON_H_
#define _REC_ROBOTINO_RPC_COMMON_H_

namespace rec
{
	namespace robotino
	{
		namespace rpc
		{
			void once();
		}
	}
}

#endif //_REC_ROBOTINO_RPC_COMMON_H_

