#!/bin/bash

DAEMONSLIST=$1

function list_include_item {
  local list="$1"
  local item="$2"
  if [[ $list =~ (^|[[:space:]])"$item"($|[[:space:]]) ]] ; then
    # yes, list include item
    result=0
  else
    result=1
  fi
  return $result
}

if list_include_item "$DAEMONSLIST" "smartsoft-common" ; then
  echo smartsoft-common included

  if list_include_item "$DAEMONSLIST" "smartsoft-master" ; then
    echo smartsoft-master already included
  else
    DAEMONSLIST="$DAEMONSLIST smartsoft-master"
  fi

  if list_include_item "$DAEMONSLIST" "smartsoft-slave" ; then
    echo smartsoft-slave already included
  else
    DAEMONSLIST="$DAEMONSLIST smartsoft-slave"
  fi

  DAEMONSLIST=$(echo $DAEMONSLIST | sed -e "s/ *smartsoft-common */ /"); 
fi

echo $DAEMONSLIST

for d in $DAEMONSLIST
do
  systemctl list-unit-files | grep $d.service
  if [ 0 -eq $? ] ; then
    echo "Stopping $d"
    systemctl stop $d
  else
    echo "$d not installed"
  fi
done


for d in $DAEMONSLIST
do
  systemctl list-unit-files | grep $d.service
  if [ 0 -eq $? ] ; then
    echo "Starting $d"
    systemctl start $d
  else
    echo "$d not installed"
  fi
done

