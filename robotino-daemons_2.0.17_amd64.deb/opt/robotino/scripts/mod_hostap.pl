#!/usr/bin/perl

# return values:
# 0: OK
# 1: Wrong number of parameters
# 2: Can not open hostapd_config_file for reading
# 3: Can not open hostapd_config_file for writing

# arguments:
# 1 - ssid
# 2 - rsn_pairwise
# 3 - psk

use File::Copy;

if( $#ARGV != 2 )
{
  print( "Usage:\n" );
  print( "mod_hostap ssid rsn_pairwise psk\n" );
  exit( 1 );
}

my ($ssid, $rsn_pairwise, $psk) = @ARGV;

my $cfgfile = "/etc/hostapd.conf";
unless (-e $cfgfile )
{
  copy( "/etc/hostapd.conf.default" , "$cfgfile" );
}

open( IFBACKUP, "<$cfgfile" ) or die "cannot open < $cfgfile: $!";

my $save = '';
while( <IFBACKUP> )
{
  $save .= $_;
}
close( IFBACKUP );

open( IF, ">$cfgfile" ) or die "cannot open < $cfgfile: $!";

my @lines = split /\n/, $save;

foreach my $line (@lines)
{
  if( $line =~ /^\s*wpa_passphrase/ )
  {
    print IF "wpa_passphrase=$psk\n";
    next;
  }
  elsif( $line =~ /^\s*rsn_pairwise/ )
  {
    print IF "rsn_pairwise=$rsn_pairwise\n";
    next;
  }
  elsif( $line =~ /^\s*ssid/ )
  {
    print IF "ssid=$ssid\n";
    next;
  }
  else
  {
    print IF "$line\n";
  }
}

close( IF );

system( "sync" );
exit( 0 );

