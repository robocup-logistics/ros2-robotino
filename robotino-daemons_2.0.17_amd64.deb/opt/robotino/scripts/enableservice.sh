#!/bin/bash

SERVICENAME=$1
ACTION=$2

#echo $SERVICENAME

SERVICEFILE="/etc/systemd/system/$SERVICENAME.service"
BAKFILE="/etc/systemd/system/$SERVICENAME.service.bak"

if [ "disable" == "$ACTION" ] ; then
  mapfile -t my_array < <( systemctl --no-legend --no-pager --all --type=service )
  for i in "${my_array[@]}"
  do
    INSTANCE="${i%% *}"
	if [[ $INSTANCE == $SERVICENAME* ]] ; then
		echo Stopping $INSTANCE
		systemctl stop $INSTANCE
	fi
  done
  
  mv -f "$SERVICEFILE" "$BAKFILE"
  ln -sf /dev/null "$SERVICEFILE"
else
  if [ -f "$BAKFILE" ] ; then
	rm -f "$SERVICEFILE"
	mv -f "$BAKFILE" "$SERVICEFILE"
  fi
fi

systemctl daemon-reload
udevadm trigger
