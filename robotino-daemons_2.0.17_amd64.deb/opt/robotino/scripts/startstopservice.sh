#!/bin/bash

SERVICE=$1
ACTION=$2

systemctl $ACTION $SERVICE