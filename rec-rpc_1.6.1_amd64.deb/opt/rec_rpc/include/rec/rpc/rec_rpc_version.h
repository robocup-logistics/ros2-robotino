#define MajorVer 1
#define MinorVer 6
#define PatchVer 1
#define Suffix ""
#define BuildVer 20200528
#define BuildVerStr "20200528"
#define VersionString "1.6.1 Build 20200528"
#define MyAppName "rec_rpc"
#define MyAppId "rec_rpc"
#define MyAppExeName ""
#define MyCompany      "REC GmbH"
#define MyPublisherURL "www.servicerobotics.eu"
#define MySupportURL   "www.servicerobotics.eu"
#define MyUpdatesURL   "www.servicerobotics.eu"
