#define MajorVer 1
#define MinorVer 1
#define PatchVer 14
#define Suffix ""
#define BuildVer 20200528
#define BuildVerStr "20200528"
#define VersionString "1.1.14 Build 20200528"
#define MyAppName "rec_robotino_api2"
#define MyAppId "rec_robotino_api2"
#define MyAppExeName ""
#define MyCompany      "REC GmbH"
#define MyPublisherURL "www.servicerobotics.eu"
#define MySupportURL   "www.servicerobotics.eu"
#define MyUpdatesURL   "www.servicerobotics.eu"
